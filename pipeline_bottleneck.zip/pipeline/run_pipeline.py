#!/usr/bin/env python3
"""
run_pipeline.py

Pipeline Orchestrator

Stage 1:
    CSV -> Kafka (radius.raw)

Stage 2:
    radius.raw -> radius.clean

Stage 3:
    radius.clean -> PostgreSQL
"""

import argparse
import os
import signal
import subprocess
import sys
import time
from typing import List

# ---------------------------------------------------------------------
# Directory Layout
#
# /workspace
# ├── data/
# └── pipeline/
#     ├── run_pipeline.py
#     └── pipeline/
#         ├── ingestion/
#         ├── processing/
#         └── storage/
# ---------------------------------------------------------------------

# /workspace/pipeline
WORKSPACE = os.path.dirname(os.path.abspath(__file__))

# /workspace
PROJECT_ROOT = os.path.dirname(WORKSPACE)


def resolve_input_path(path: str) -> str:
    """
    Convert input path to an absolute path.

    Relative paths are resolved from PROJECT_ROOT.
    """

    if os.path.isabs(path):
        abs_path = os.path.abspath(path)
    else:
        abs_path = os.path.abspath(os.path.join(PROJECT_ROOT, path))

    if not os.path.isfile(abs_path):
        raise FileNotFoundError(
            "Input CSV not found:\n{}".format(abs_path)
        )

    return abs_path


def run_stage(script_relpath: str, *args: str) -> subprocess.Popen:
    """
    Launch one pipeline stage.
    """

    script_path = os.path.join(WORKSPACE, script_relpath)

    if not os.path.isfile(script_path):
        raise FileNotFoundError(script_path)

    env = os.environ.copy()
    env["PYTHONPATH"] = WORKSPACE

    command = [
        sys.executable,
        script_path,
        *args,
    ]

    return subprocess.Popen(
        command,
        cwd=WORKSPACE,
        env=env,
    )


def stop_all(processes: List[subprocess.Popen]) -> None:
    """
    Stop all child processes.
    """

    print("\n>>> Stopping pipeline...")

    for p in processes:
        if p.poll() is None:
            try:
                p.terminate()
            except Exception:
                pass

    for p in processes:
        if p.poll() is None:
            try:
                p.wait(timeout=5)
            except Exception:
                try:
                    p.kill()
                except Exception:
                    pass

    print(">>> Pipeline stopped.")


def main():

    parser = argparse.ArgumentParser(
        description="RADIUS Pipeline Orchestrator"
    )

    parser.add_argument(
        "--input",
        required=True,
        help="CSV input file",
    )

    args = parser.parse_args()

    input_file = resolve_input_path(args.input)

    print("==================================================")
    print("Workspace :", WORKSPACE)
    print("Project   :", PROJECT_ROOT)
    print("Input CSV :", input_file)
    print("==================================================")

    processes = []

    try:

        print(">>> [S1] CSV -> radius.raw")

        s1 = run_stage(
            "pipeline/ingestion/producer.py",
            "--file",
            input_file,
        )

        processes.append(s1)

        time.sleep(2)

        print(">>> [S2] radius.raw -> radius.clean")

        s2 = run_stage(
            "pipeline/processing/processor.py"
        )

        processes.append(s2)

        time.sleep(1)

        print(">>> [S3] radius.clean -> PostgreSQL")

        s3 = run_stage(
            "pipeline/storage/writer.py"
        )

        processes.append(s3)

        def shutdown(signum, frame):
            stop_all(processes)
            sys.exit(0)

        signal.signal(signal.SIGINT, shutdown)
        signal.signal(signal.SIGTERM, shutdown)

        print()
        print("Pipeline is running.")
        print("Spark UI: http://localhost:4040")
        print()

        s1.wait()

        print(">>> Producer finished.")

        while True:
            time.sleep(1)

    except KeyboardInterrupt:
        stop_all(processes)

    except Exception as e:
        stop_all(processes)
        raise e


if __name__ == "__main__":
    main()