#!/usr/bin/env python3
"""
Stage S2 -- Ap dung 6 validation rules tren moi record.
Record hop le -> `radius.valid`. Record loi -> `radius.invalid` + ghi `invalid_log`.

Cac rule duoc dinh nghia o file nay deu la pure async function, nhan vao
1 dict record (+ httpx.AsyncClient cho rule can goi mock service) va tra
ve ValidationResult. Orchestrator execute_validation_pipeline() chay tuan
tu R1->R6, dung lai (fail-fast) ngay khi gap rule dau tien fail.
"""

import re
import os
import httpx
import asyncio
from typing import Tuple, Optional, Dict, Any
from dataclasses import dataclass


@dataclass
class ValidationResult:
    """Ket qua cua 1 rule validation.

    Attributes:
        is_valid: True neu record pass rule nay.
        error_code: Ma loi (vd ERR_MISSING_FIELD) khi is_valid=False.
        error_message: Mo ta chi tiet loi, dung cho invalid_log.
        warn_code: WARN_RULE_BYPASSED khi circuit breaker mo va rule
            bi bo qua (record van duoc tinh la valid).
    """
    is_valid: bool
    error_code: Optional[str] = None
    error_message: Optional[str] = None
    warn_code: Optional[str] = None


# Cau hinh Endpoints tu moi truong (xem mock_services/README.md)
ITU_E164_SERVICE_URL = os.getenv("ITU_E164_SERVICE_URL", "http://localhost:8300")
HLR_HSS_SERVICE_URL = os.getenv("HLR_HSS_SERVICE_URL", "http://localhost:8200")
GSMA_TAC_SERVICE_URL = os.getenv("GSMA_TAC_SERVICE_URL", "http://localhost:8100")

# --- HA TANG RESILIENCE (RETRY BACKOFF & CIRCUIT BREAKER) ---

#: So lan fail lien tiep toi da truoc khi circuit breaker mo (Open)
CIRCUIT_BREAKER_LIMIT = 5

#: Bo dem fail hien tai cho moi mock service. Reset ve 0 khi 1 request
#: thanh cong (ke ca khi response la loi nghiep vu 400/404 -- van la
#: "thanh cong ve mat ha tang"). Day la state GLOBAL, test phai reset
#: truoc/sau moi test case (xem tests/.../README.md).
failed_counters: Dict[str, int] = {
    "ITU_E164": 0,
    "HLR_HSS": 0,
    "GSMA_TAC": 0,
}


async def invoke_external_api_with_resilience(
    service_key: str,
    client: httpx.AsyncClient,
    method: str,
    url: str,
    **kwargs,
) -> Tuple[Optional[httpx.Response], Optional[str]]:
    """Goi 1 mock service voi circuit breaker + retry/backoff.

    Quy trinh:
        1. Neu failed_counters[service_key] >= CIRCUIT_BREAKER_LIMIT
           -> breaker dang "Open" -> tra ve (None, "WARN_RULE_BYPASSED")
           ngay, KHONG goi network.
        2. Nguoc lai, goi client.get/post voi timeout=2.0s.
           - Thanh cong (bat ke status code) -> reset counter ve 0,
             tra ve (response, None).
           - TimeoutException / RequestError -> retry toi da 2 lan
             voi exponential backoff (0.5s -> 1.0s). Het retry ->
             tang failed_counters[service_key], tra ve
             (None, "ERR_EXTERNAL_TIMEOUT" | "ERR_EXTERNAL_CONN_FAIL").

    Args:
        service_key: 1 trong "ITU_E164", "HLR_HSS", "GSMA_TAC" --
            key trong failed_counters.
        client: httpx.AsyncClient dung chung cho ca batch.
        method: "GET" hoac "POST".
        url: full URL cua mock service endpoint.
        **kwargs: forward toi client.get/post (vd json=...).

    Returns:
        (response, error_code):
            - (Response, None) neu goi thanh cong.
            - (None, "WARN_RULE_BYPASSED") neu breaker dang Open.
            - (None, "ERR_EXTERNAL_TIMEOUT" | "ERR_EXTERNAL_CONN_FAIL")
              neu het retry van loi.
    """
    global failed_counters

    if failed_counters[service_key] >= CIRCUIT_BREAKER_LIMIT:
        return None, "WARN_RULE_BYPASSED"

    retries = 2
    backoff_delay = 0.5  # bat dau tu 500ms

    for attempt in range(retries + 1):
        try:
            if method.upper() == "POST":
                response = await client.post(url, timeout=2.0, **kwargs)
            else:
                response = await client.get(url, timeout=2.0, **kwargs)

            failed_counters[service_key] = 0
            return response, None

        except httpx.TimeoutException:
            if attempt == retries:
                failed_counters[service_key] += 1
                return None, "ERR_EXTERNAL_TIMEOUT"

        except httpx.RequestError:
            if attempt == retries:
                failed_counters[service_key] += 1
                return None, "ERR_EXTERNAL_CONN_FAIL"

        await asyncio.sleep(backoff_delay)
        backoff_delay *= 2

    return None, "ERR_EXTERNAL_TIMEOUT"


# ==============================================================================
# RULE 1: Mandatory fields khong null
# ==============================================================================
async def validate_mandatory_fields(record: Dict[str, Any]) -> ValidationResult:
    """R1: kiem tra cac field bat buoc khong rong/null.

    Cac field bat buoc, kiem theo thu tu (bao loi tai field dau tien
    bi thieu): acct_status_type, acct_session_id, msisdn, imsi, imei,
    event_timestamp.

    Returns:
        ValidationResult(is_valid=False, error_code="ERR_MISSING_FIELD")
        neu thieu field; nguoc lai is_valid=True.
    """
    mandatory_fields = [
        "acct_status_type", "acct_session_id", "msisdn",
        "imsi", "imei", "event_timestamp",
    ]
    for field in mandatory_fields:
        if field not in record or record[field] is None or str(record[field]).strip() == "":
            return ValidationResult(
                is_valid=False,
                error_code="ERR_MISSING_FIELD",
                error_message=f"{field} is required",
            )
    return ValidationResult(is_valid=True)


# ==============================================================================
# RULE 2: MSISDN format E.164 + operator prefix hop le
# ==============================================================================
async def validate_msisdn_format(record: Dict[str, Any], client: httpx.AsyncClient) -> ValidationResult:
    """R2: kiem tra format E.164 (regex local), sau do goi ITU E.164
    Mock API (POST /validate) de xac nhan country code + operator
    prefix + do dai subscriber number hop le.

    Returns:
        - ERR_INVALID_MSISDN neu regex fail HOAC mock tra valid=False.
        - WARN_RULE_BYPASSED (is_valid=True) neu circuit breaker mo.
        - ERR_EXTERNAL_* neu mock service loi ha tang.
        - is_valid=True neu mock tra valid=True.
    """
    msisdn = str(record.get("msisdn", "")).strip()
    if not re.match(r"^\+[1-9]\d{1,14}$", msisdn):
        return ValidationResult(is_valid=False, error_code="ERR_INVALID_MSISDN", error_message="Violate E.164 regex")

    url = f"{ITU_E164_SERVICE_URL}/validate"
    res, err = await invoke_external_api_with_resilience("ITU_E164", client, "POST", url, json={"msisdn": msisdn})

    if err == "WARN_RULE_BYPASSED":
        return ValidationResult(is_valid=True, warn_code="WARN_RULE_BYPASSED")
    if err:
        return ValidationResult(is_valid=False, error_code=err, error_message="ITU service unavailable")

    if res.status_code == 200 and res.json().get("valid") is True:
        return ValidationResult(is_valid=True)
    return ValidationResult(is_valid=False, error_code="ERR_INVALID_MSISDN", error_message="Invalid prefix/operator")


# ==============================================================================
# RULE 3: IMSI ton tai trong HLR
# ==============================================================================
async def validate_imsi_in_hlr(record: Dict[str, Any], client: httpx.AsyncClient) -> ValidationResult:
    """R3: goi HLR/HSS Mock API (GET /subscribers/by-imsi/{imsi}) de
    xac nhan IMSI ton tai trong subscriber registry.

    Returns:
        - ERR_IMSI_NOT_IN_HLR neu mock tra exists=False hoac 404.
        - WARN_RULE_BYPASSED (is_valid=True) neu circuit breaker mo.
        - ERR_EXTERNAL_* neu mock service loi ha tang.
        - is_valid=True neu mock tra exists=True.
    """
    imsi = str(record.get("imsi", "")).strip()
    url = f"{HLR_HSS_SERVICE_URL}/subscribers/by-imsi/{imsi}"

    res, err = await invoke_external_api_with_resilience("HLR_HSS", client, "GET", url)

    if err == "WARN_RULE_BYPASSED":
        return ValidationResult(is_valid=True, warn_code="WARN_RULE_BYPASSED")
    if err:
        return ValidationResult(is_valid=False, error_code=err, error_message="HLR service unavailable")

    if res.status_code == 200 and res.json().get("exists") is True:
        return ValidationResult(is_valid=True)
    return ValidationResult(is_valid=False, error_code="ERR_IMSI_NOT_IN_HLR", error_message="IMSI not found in HLR")


# ==============================================================================
# RULE 4a: IMEI pass Luhn algorithm
# ==============================================================================
async def validate_imei_luhn(record: Dict[str, Any]) -> ValidationResult:
    """R4a: kiem tra IMEI dung 15 chu so va pass Luhn checksum.

    Thuat toan: voi 14 chu so dau (index 0-13), nhan doi gia tri tai
    cac vi tri le (index 1,3,5,...), neu > 9 thi tru 9. Tong tat ca
    lai, check digit dung = (10 - (sum % 10)) % 10, phai bang
    imei[14].

    Returns:
        ERR_IMEI_LUHN_FAIL neu khong du 15 so, khong phai toan chu so,
        hoac check digit sai. Nguoc lai is_valid=True.
    """
    imei = str(record.get("imei", "")).strip()
    if not imei.isdigit() or len(imei) != 15:
        return ValidationResult(is_valid=False, error_code="ERR_IMEI_LUHN_FAIL", error_message="IMEI must be 15 digits")

    sum_ = 0
    for i in range(14):
        digit = int(imei[i])
        if i % 2 == 1:
            digit *= 2
            if digit > 9:
                digit -= 9
        sum_ += digit
    if (10 - (sum_ % 10)) % 10 != int(imei[14]):
        return ValidationResult(is_valid=False, error_code="ERR_IMEI_LUHN_FAIL", error_message="Luhn check fail")
    return ValidationResult(is_valid=True)


# ==============================================================================
# RULE 4b: TAC (6 chu so dau IMEI) co trong GSMA TAC DB
# ==============================================================================
async def validate_imei_tac(record: Dict[str, Any], client: httpx.AsyncClient) -> ValidationResult:
    """R4b: goi GSMA TAC Mock API (GET /tac/{tac}) voi 6 chu so dau
    cua IMEI de xac nhan TAC duoc GSMA cap phep.

    Returns:
        - ERR_IMEI_TAC_UNKNOWN neu mock tra exists=False hoac 404.
        - WARN_RULE_BYPASSED (is_valid=True) neu circuit breaker mo.
        - ERR_EXTERNAL_* neu mock service loi ha tang.
        - is_valid=True neu mock tra exists=True.
    """
    imei = str(record.get("imei", "")).strip()
    tac = imei[:6]
    url = f"{GSMA_TAC_SERVICE_URL}/tac/{tac}"

    res, err = await invoke_external_api_with_resilience("GSMA_TAC", client, "GET", url)

    if err == "WARN_RULE_BYPASSED":
        return ValidationResult(is_valid=True, warn_code="WARN_RULE_BYPASSED")
    if err:
        return ValidationResult(is_valid=False, error_code=err, error_message="GSMA service unavailable")

    if res.status_code == 200 and res.json().get("exists") is True:
        return ValidationResult(is_valid=True)
    return ValidationResult(is_valid=False, error_code="ERR_IMEI_TAC_UNKNOWN", error_message="Unknown TAC")


# ==============================================================================
# RULE 5: acct_status_type in {Start, Stop, Interim-Update}
# ==============================================================================
async def validate_acct_status_type(record: Dict[str, Any]) -> ValidationResult:
    """R5: acct_status_type phai thuoc {Start, Stop, Interim-Update}.

    Returns:
        ERR_INVALID_STATUS neu khong khop; nguoc lai is_valid=True.
    """
    if str(record.get("acct_status_type", "")).strip() not in {"Start", "Stop", "Interim-Update"}:
        return ValidationResult(is_valid=False, error_code="ERR_INVALID_STATUS", error_message="Invalid status type")
    return ValidationResult(is_valid=True)


# ==============================================================================
# RULE 6: event_timestamp trong khoang hop le
# ==============================================================================
async def validate_event_timestamp(record: Dict[str, Any]) -> ValidationResult:
    """R6: event_timestamp phai la Unix timestamp (giay) hop le, nam
    trong [2000-01-01, 2100-01-01) -- tuong duong
    [946684800, 4102444800).

    Returns:
        ERR_INVALID_TIMESTAMP neu khong parse duoc int hoac ngoai
        khoang; nguoc lai is_valid=True.
    """
    try:
        ts = int(str(record.get("event_timestamp", "")).strip())
        if not (946684800 <= ts <= 4102444800):
            return ValidationResult(is_valid=False, error_code="ERR_INVALID_TIMESTAMP", error_message="Timestamp out of bounds")
        return ValidationResult(is_valid=True)
    except ValueError:
        return ValidationResult(is_valid=False, error_code="ERR_INVALID_TIMESTAMP", error_message="Timestamp is not int")


# ==============================================================================
# DONG CO DIEU PHOI CHUOI TUAN TU (ORCHESTRATOR)
# ==============================================================================
async def execute_validation_pipeline(record: Dict[str, Any], client: httpx.AsyncClient) -> Tuple[ValidationResult, Optional[str]]:
    """Chay tuan tu toan bo 6 Rules (R1 -> R2 -> R3 -> R4a -> R4b ->
    R5 -> R6). Gap rule dau tien fail -> dung ngay (fail-fast),
    KHONG chay cac rule sau.

    Neu mot rule pass nhung kem warn_code (circuit breaker bypass),
    warn_code duoc tich luy va tra ve cung ket qua cuoi (record van
    duoc tinh la valid neu khong rule nao fail).

    Args:
        record: dict 1 row RADIUS (theo RAW_RADIUS_SCHEMA).
        client: httpx.AsyncClient dung chung cho ca batch.

    Returns:
        (ValidationResult, warn_code):
            - Neu mot rule fail: (ValidationResult cua rule do, None).
            - Neu tat ca pass: (ValidationResult(is_valid=True),
              warn_code cuoi cung neu co, None neu khong).
    """
    pipeline_rules = [
        (validate_mandatory_fields, False),
        (validate_msisdn_format, True),
        (validate_imsi_in_hlr, True),
        (validate_imei_luhn, False),
        (validate_imei_tac, True),
        (validate_acct_status_type, False),
        (validate_event_timestamp, False),
    ]

    accumulated_warn = None

    for rule_func, requires_client in pipeline_rules:
        if requires_client:
            res = await rule_func(record, client)
        else:
            res = await rule_func(record)

        if not res.is_valid:
            return res, None

        if res.warn_code:
            accumulated_warn = res.warn_code

    return ValidationResult(is_valid=True), accumulated_warn